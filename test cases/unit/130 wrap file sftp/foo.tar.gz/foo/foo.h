#ifndef FOO_H
#define FOO_H

int foo_double(int x);

#endif
