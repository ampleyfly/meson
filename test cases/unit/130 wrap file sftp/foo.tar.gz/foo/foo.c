#include "foo.h"

int foo_double(int x) {
    return 2 * x;
}
